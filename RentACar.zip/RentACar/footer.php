<footer>
	<p type="copyright">© Copyright 2018 by >> Andrej, Andrija & Marin << </p> 
	
	<div class="footerstyle">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="#">Cars</a></li>
			<li><a href="#">Offers</a></li>
			<li><a href="About_rent.php">About rent</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
	</div>	
</footer>

</body>

</html>