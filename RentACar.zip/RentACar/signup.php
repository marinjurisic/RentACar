<?php 
	include_once 'header.php';
?>



<section>
	<div>
		<img src="slike/signuppic.jpg" class="signup-background">
	</div>
		<form class="signup-form" action="includes/signup.inc.php" method="POST">
			<input type="text" name="ime" placeholder="Ime">
			<input type="text" name="prezime" placeholder="Prezime">
			<input type="text" name="username" placeholder="Username">
			<input type="text" name="email" placeholder="E-mail">
			<input type="text" name="br_telefona" placeholder="Broj telefona">
			<input type="password" name="lozinka" placeholder="Lozinka">
			<button type="submit" name="submit2">Sign Up</button>
		</form>
</section>


<?php 
	include_once 'footer.php';
?>