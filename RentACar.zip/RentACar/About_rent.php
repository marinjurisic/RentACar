<?php 
	include_once 'header.php';
?>

<section class="pravilnik">
	<h2>LAURUS RENT-A-CAR d.o.o.</h2>
	<h3>Pravilnik o iznajmljivanju vozila</h3>
	<p>Prilikom iznajmljivanja automobila, LAURUS Rent a car vam daje ugovor kojim se unajmitelj obvezuje na sljedeće stavke:</p>
	<p>1. Potpisivanjem ovog Ugovora unajmitelj potvrđuje da je preuzeo automobil u ispravnom stanju, te da će ga korektno i savjesno eksploatirati.</p>
	<p>2. Minimalna starost vozača je dvadeset i jedna godina i vozačko iskustvo dvije godine. Minimalni najam je jedan dan (24 sata). Porez na usluga nije uračunat u cijenu najma.<br>Pogonsko gorivo nije uračunato u cijenu najma i unajmitelj preuzima automobil sa punim rezervoarom pogonskog goriva i dužan ga je vratiti puna rezervoara.<br>U protivnom se usluga punjenja naplaćuje 5 KM. Automobil je osiguran na osnovu:<br>a) auto kasko;<br>b) auto odgovornost.</p>
	<p>3. Ako je vozilo korišteno u skladu sa Ugovorom, odgovornost unajmitelja je u visini iznosa franšize u cjeniku Rent a car LAURUS.<br>U slučaju da unajmitelj prihvati plaćanje otkupa franšize po Ugovoru u potpunosti se isključuje odgovornost unajmitelja za štetu, koju priznaje o osiguravajuće društvo, nastalu na unajmljenom automobilu.</p>
	<p>4. Unajmitelj se obvezuje da će automobil vratiti u ugovoreno vrijeme ili ranije na zahtjev iznajmitelja. U slučaju da Unajmitelj želi produžiti najam dužan je zatražiti suglasnost od Rent a car LAURUS najmanje dvadeset i četiri sata unaprijed  te tom prilikom uplatiti dodatni depozit.</p>
	<p>5. Depozit za najam automobila se polaže u iznosuu cijene za predviđeni najam uvećan 20%.</p>
	<p>6. Iznajmljenim automobilom može upravljati samo osoba koja je navedena Ugovorom kao vozač ili osoba navedena kao drugi vozač, u slučaju da ispunjava sve kvalifikacije i posjeduje dokumente tražene u Ugovoru.</p>
	<p>7. Prava i obveze iz ovoga Ugovora unajmitelj ne može prenijeti na drugu osobu, te ne može otuđiti vozilo ili pojedine dijelove.<br>Također, automobil se ne može koristiti:<br>za sportska natjecanja, za plaćeni prijevoz robe i putnika, za vuču drugog vozila; koristiti ga tako da prekorači opterećenje (prom.dozvola) ili prevozi veći broj putnika od dopuštenog što je propisano za određeni tip vozila; automobilom ne može upravljati osoba koja je pod utjecajem alkohola ili narkotika; za prijevoz životinja, lako zapaljivih materijala, eksploziva, raznih materijala koji ispuštaju jak, oštar i neugodan miris.</p>
	<p>8. Ako Unajmitelj prekorači ugovoreni rok za vraćanje automobila bez suglasnosti iznajmitelja, automobil će se smatrati otuđenim, a o čemu će iznajmitelj izvijestiti policiju, nakon čega Unajmitelj snosi kaznenu, moralnu i materijalnu odgovornost.</p>
	<p>9. Unajmitelj je dužan voditi brigu o tehničkoj ispravnosti automobila; <br>redovito kontrolirati rashladnu tekućinu;<br>kontrolirati nivo ulja u motoru;<br>kontrolirati tlak u pneumaticima(gumama).</p>
	<p>10. Ako se ustanovi da je unajmitelj automobile koristio nekorektno i nesvjesno, te tako prouzročio štete, bit će odgovoran za iste.</p>
	<p>11. U slučaju da dođe do šteta na automobilu prouzročenih nepravilnim korištenjem i kod fizičkih oštećenja, unajmitelj će se teretiti za troškove provoženja automobila (šlepanja), troškove smanjenja vrijednosti vozila i gubitka prihoda nastalog po tom osnovu.</p>
	<p>12. Unajmitelj će se također teretiti za troškove koje LAURUS Rent a car d.o.o. može imati prema trećim osobama, ako su one nastale kao plod nepravilne uporabe automobila.</p>
	<p>13. Unajmitelj je odgovoran za štete nastale tijekom najma, u slučaju da je dao netočne i falsificirane podatke o sebi, svojoj adresi ili vozačkim dokumentima.</p>
	<p>14. Tijekom korištenja automobila unajmitelj je dužan zaključavati vozilo, te ključeve i dokumente vozila uzimati sa sobom prilikom napuštanja automobila.</p>
	<p>15. Nakon najma Unajmitelj je dužan predati ispravno i neoštećeno vozilo što će ustanoviti predstavnik LAURUS Rent a car-a, te punoga rezervoara i kompletnom dokumentacijom automobila, kao i ključeve ili nadoknaditi nastanak istih.</p>
	<p>16. U vrijeme trajanja najma Unajmitelj snosi troškove parkiranja, garažiranja, kao i kazni za prometne prekršaje.</p>
	<p>17. Ako Unajmitelj prihvati uvjete osiguranja putnika u automobilu, ostvarit će pravo na odštetu prema odredbama Ugovora o osobnom osiguranju sklopljenog između LAURUS rent a car-a i osiguravajućeg društva.</p>
	<p>18. U slučaju nezgode - udesa, unajmitelj se obvezuje štititi interese Rent a car tvrtke LAURUS tako što će:<br>zabilježiti imena i adrese učesnika i svjedoka;<br>osigurati - skloniti na sigurno automobil prije napuštanja;<br>obavjestiti LAURUS Rent a car o nezgodi, pismeno izvijestiti o šteti;<br>pozvati i obavjestiti organe policije, te ih sačekati do izvršenja očevida.</p>
	<p>19. Ako Unajmitelj propusti učiniti navedene mjere bit će odgovoran za posljedice i štete koje LAURUS Rent a car može imati zbog toga.<br>Službeni cjenik je sastavni dio Ugovora i on vrijedi u vrijeme sklapanja ovoga Ugovora.</p>
	<p>20. Izmjene ovog Ugovora su moguće uz pismenu suglasnost strana i on se izmjenjuje aneksom na postojeći Ugovor.</p>
	<p>21. U slučaju spora, nadležan je sud u Širokom Brijegu, Bosna i Hercegovina.</p>
</section>




<?php 
	include_once 'footer.php';
?>