<?php

session_start();

?>


<!DOCTYPE html>

<head>

<title>Rent A Car | Naslovnica</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>


<header>
	<nav class="menu">
		<div class="menu-logo">
			<a href="index.php"><img src="slike/logo.jpg" width="132" height="50"></a>
		</div>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="#">Cars</a></li>
			<li><a href="#">Offers</a></li>
			<li><a href="About_rent.php">About rent</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
		<?php 
			if(isset($_SESSION['ko_id'])) {
				echo 	'<form class="logout-form" action="includes/logout.inc.php" method="POST">
							<button type="submit" name="submit3">Logout</button>
						</form>';
			} 	else {
					echo 	'<form action="includes/login.inc.php" method="POST">
								<input type="text" name="username" placeholder="Username/email">	
								<input type="password" name="lozinka" placeholder="Password">
								<button type="submit" name="submit1">Login</button>
								<button type="submit" name="submit2"><a href="signup.php">Sign Up</a></button>
							</form>';
			}
		?>
		
	</nav>
</header>



</script>