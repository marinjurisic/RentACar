<?php 
	include_once 'header.php';
?>

<script type="text/javascript">
	var i = 0;
	var images = [];
	var time = 3000;
	
	images[0] = 'slike/ponuda.jpg';
	images[1] = 'slike/ponuda1.jpg';
	images[2] = 'slike/ponuda2.png';
	images[3] = 'slike/ponuda3.jpg';
	
	function changeImg(){
		document.slide.src = images[i];
		
		if(i < images.length - 1){
			i++;
		} 	else {
			i = 0;
		}
		setTimeout("changeImg()", time);
	}
	
	window.onload = changeImg;
</script>

<div>
	<?php
	if (isset($_SESSION['ko_id'])) {
		echo '<img name="slide" width="100%" height="500">';
	} else {
			echo '<img name="slide" width="100%" height="500">';
	}
	?>
</div>

<?php 
	include_once 'footer.php';
?>