-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2018 at 11:16 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_rentacar`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `booking_id` int(11) NOT NULL,
  `pocetak_najma` datetime(6) NOT NULL,
  `zavrsetak_najma` datetime(6) NOT NULL,
  `broj_dana` int(20) NOT NULL,
  `paypal` varchar(20) NOT NULL,
  `v_id` int(11) NOT NULL,
  `z_id` int(11) NOT NULL,
  `k_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE IF NOT EXISTS `korisnik` (
  `k_id` int(11) NOT NULL,
  `k_ime` varchar(20) NOT NULL,
  `k_prezime` varchar(20) NOT NULL,
  `k_username` varchar(30) NOT NULL,
  `k_email` varchar(50) NOT NULL,
  `k_br_telefona` int(9) NOT NULL,
  `k_lozinka` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tip`
--

CREATE TABLE IF NOT EXISTS `tip` (
  `t_id` int(11) NOT NULL,
  `t_naziv` varchar(20) NOT NULL,
  `broj_sjedista` int(10) NOT NULL,
  `broj_vrata` varchar(5) NOT NULL,
  `gorivo` varchar(20) NOT NULL,
  `prijenos` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tvrtka`
--

CREATE TABLE IF NOT EXISTS `tvrtka` (
  `tvrtka_id` int(11) NOT NULL,
  `naziv_tvrtke` varchar(30) NOT NULL,
  `email_tvrtke` varchar(50) NOT NULL,
  `fax_tvrtke` varchar(50) NOT NULL,
  `adresa` varchar(100) NOT NULL,
  `broj_racuna` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vozilo`
--

CREATE TABLE IF NOT EXISTS `vozilo` (
  `v_id` int(11) NOT NULL,
  `v_naziv` varchar(30) NOT NULL,
  `godina_proizvodnje` year(4) NOT NULL,
  `konjske_snage` int(20) NOT NULL,
  `kilomteraza` int(15) NOT NULL,
  `oprema` text NOT NULL,
  `t_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `zaposlenici`
--

CREATE TABLE IF NOT EXISTS `zaposlenici` (
  `z_id` int(11) NOT NULL,
  `z_ime` varchar(20) NOT NULL,
  `z_prezime` varchar(20) NOT NULL,
  `z_titula` varchar(30) NOT NULL,
  `tvrtka_id` int(11) NOT NULL,
  `placa` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `k_id` (`k_id`),
  ADD KEY `z_id` (`z_id`),
  ADD KEY `v_id` (`v_id`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`k_id`);

--
-- Indexes for table `tip`
--
ALTER TABLE `tip`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `tvrtka`
--
ALTER TABLE `tvrtka`
  ADD PRIMARY KEY (`tvrtka_id`);

--
-- Indexes for table `vozilo`
--
ALTER TABLE `vozilo`
  ADD PRIMARY KEY (`v_id`),
  ADD KEY `t_id` (`t_id`);

--
-- Indexes for table `zaposlenici`
--
ALTER TABLE `zaposlenici`
  ADD PRIMARY KEY (`z_id`),
  ADD KEY `tvrtka_id` (`tvrtka_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `k_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tip`
--
ALTER TABLE `tip`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tvrtka`
--
ALTER TABLE `tvrtka`
  MODIFY `tvrtka_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `vozilo`
--
ALTER TABLE `vozilo`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zaposlenici`
--
ALTER TABLE `zaposlenici`
  MODIFY `z_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`z_id`) REFERENCES `zaposlenici` (`z_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`k_id`) REFERENCES `korisnik` (`k_id`),
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`v_id`) REFERENCES `vozilo` (`v_id`);

--
-- Constraints for table `vozilo`
--
ALTER TABLE `vozilo`
  ADD CONSTRAINT `vozilo_ibfk_1` FOREIGN KEY (`t_id`) REFERENCES `tip` (`t_id`);

--
-- Constraints for table `zaposlenici`
--
ALTER TABLE `zaposlenici`
  ADD CONSTRAINT `zaposlenici_ibfk_1` FOREIGN KEY (`tvrtka_id`) REFERENCES `tvrtka` (`tvrtka_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
