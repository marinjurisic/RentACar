<?php 
	include_once 'header.php';
?>
<div>
	<img src="slike/kontakt.jpg" class="contact-background">
</div>
<section class="contact">
	<p>Contact us!</p>
	<form class="contact-form">
		<input type="text" name="name" placeholder="Ime">
		<input type="text" name="mail" placeholder="E-mail">
		<input type="text" name="subject" placeholder="Predmet">
		<textarea  name="message" placeholder="..."></textarea>
		<button type="submit" name="submit">SEND</button>
	</form>
</section>

<?php 
	include_once 'footer.php';
?>