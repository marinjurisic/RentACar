<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "database_rentacar";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);