<?php 
	
session_start();
	
if (isset($_POST['submit1'])){
	
	include_once 'dbh.inc.php';
	
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$lozinka = mysqli_real_escape_string($conn, $_POST['lozinka']);
	
	//errori
	//provjera praznih mjesta
	
	if (empty($username) || empty($lozinka)){
		header("Location: ../index.php?login=empty");
		exit();
	} else {
		$sql = "SELECT * FROM korisnik WHERE k_username='$username' OR k_email='$username'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck < 1) {
			header("Location: ../index.php?login=error");
			exit();
		} else {
			if ($row = mysqli_fetch_assoc($result)) {
				//de-hashiranje sifre
				$hashedPwdCheck = password_verify($lozinka, $row['k_lozinka']);
				if($hashedPwdCheck == false) {
					header("Location: ../index.php?login=error");
					exit();
				} else if ($hashedPwdCheck == true) {
					//logiraj ovdje korisnika
					$_SESSION['ko_id'] = $row['k_id'];
					$_SESSION['ko_ime'] = $row['k_ime'];
					$_SESSION['ko_prezime'] = $row['k_prezime'];
					$_SESSION['ko_username'] = $row['k_username'];
					$_SESSION['ko_email'] = $row['k_email'];
					$_SESSION['ko_br_telefona'] = $row['k_br_telefona'];
					header("Location: ../index.php?login=succes");
					exit();
				}
			}
		}
	}
	
} 	else {
	header("Location: ../index.php?login=error");
	exit();
}