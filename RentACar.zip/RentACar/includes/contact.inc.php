<?php

if(isset($_POST['submit'])){
	&name = $_POST['subject'];
	&subject = $_POST['name'];
	&mailFrom = $_POST['mail'];
	&message = $_POST['message'];
	
	$mailTo = "jurisicn.marin@gmail.com";
	&headers = "From: ".$mailFrom;
	$txt = "Primili ste postu od ".$name.".\n\n".$message;
	
	mail($mailTo, $subject, $txt, $headers);
	header("Location: index.php?mailsend");
}