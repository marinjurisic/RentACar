<?php

if (isset($_POST['submit2'])){
	
	include_once 'dbh.inc.php';
	
	$ime = mysqli_real_escape_string($conn, $_POST['ime']);
	$prezime = mysqli_real_escape_string($conn, $_POST['prezime']);
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$br_telefona = mysqli_real_escape_string($conn, $_POST['br_telefona']);
	$lozinka = mysqli_real_escape_string($conn, $_POST['lozinka']);
	
	//errori
	//provjera za prazna polja
	
	if (empty($ime) || empty($prezime) || empty($email) || empty($username) || empty($br_telefona) || empty($lozinka)){
		header("Location: ../signup.php?signup=empty");
		exit();
	} else {
		//provjera da li su znakovi validni
		if(!preg_match("/^[a-zA-Z]*$/", $ime) || !preg_match("/^[a-zA-Z]*$/", $prezime)){
			header("Location: ../signup.php?signup=invalid");
			exit();
		} else {
			//provjera validnosti email-a
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				header("Location: ../signup.php?signup=invalidemail");
				exit();
			} else {
				$sql = "SELECT * FROM korisnik WHERE k_username = '$username'";
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				if ($resultCheck > 0) {
					header("Location: ../signup.php?signup=taken");
				    exit();
				} else {
					//hash sifre
					$hashedPwd = password_hash($lozinka, PASSWORD_DEFAULT);
					//ubacivanje korsnika u bazu
					$sql = "INSERT INTO korisnik (k_ime, k_prezime, 
					k_username, k_email, k_br_telefona, k_lozinka)
					VALUES ('$ime', '$prezime', '$username', 
					'$email', '$br_telefona', '$hashedPwd');";
					mysqli_query($conn, $sql);
					header("Location: ../signup.php?signup=succes");
				    exit();
				}
			}
		}
	}
	
} 	else {
		header("Location: ../signup.php");
		exit();
}